from dataclasses import dataclass, asdict
import json
from pathlib import Path

@dataclass
class Phase:
    name: str
    green_seconds: int
    yellow_seconds: int
    intergreen_seconds: int

class SignalPlan:
    def __init__(self, phases):
        if len(phases) < 2:
            raise ValueError("Нужно минимум две фазы.")
        self.phases = list(phases)
        self.validate()

    def validate(self):
        if len(self.phases) < 2:
            raise ValueError("Нужно минимум две фазы.")
        for i, phase in enumerate(self.phases, 1):
            if not phase.name.strip():
                raise ValueError(f"Фаза {i}: укажите название.")
            if not isinstance(phase.green_seconds, int) or phase.green_seconds < 5:
                raise ValueError(f"Фаза {i}: зелёный должен быть целым числом не менее 5 с.")
            if not isinstance(phase.yellow_seconds, int) or phase.yellow_seconds < 1:
                raise ValueError(f"Фаза {i}: жёлтый должен быть целым числом не менее 1 с.")
            if not isinstance(phase.intergreen_seconds, int) or phase.intergreen_seconds < 0:
                raise ValueError(f"Фаза {i}: межфазный интервал не может быть отрицательным.")
        if self.cycle_seconds > 300:
            raise ValueError("Длина цикла превышает 300 с; проверьте введённые интервалы.")

    @classmethod
    def default(cls):
        return cls([Phase("Север—Юг", 35, 3, 2), Phase("Восток—Запад", 30, 3, 2)])

    @property
    def cycle_seconds(self):
        return sum(p.green_seconds + p.yellow_seconds + p.intergreen_seconds for p in self.phases)

    def to_dict(self):
        return {"schema_version": 1, "phases": [asdict(p) for p in self.phases]}

    def save(self, path):
        Path(path).write_text(json.dumps(self.to_dict(), ensure_ascii=False, indent=2), encoding="utf-8")

    @classmethod
    def load(cls, path):
        try:
            data = json.loads(Path(path).read_text(encoding="utf-8"))
            if data.get("schema_version") != 1:
                raise ValueError("Неизвестная версия формата плана.")
            return cls([Phase(**item) for item in data["phases"]])
        except (OSError, json.JSONDecodeError, KeyError, TypeError) as exc:
            raise ValueError(f"Не удалось загрузить план: {exc}") from exc
