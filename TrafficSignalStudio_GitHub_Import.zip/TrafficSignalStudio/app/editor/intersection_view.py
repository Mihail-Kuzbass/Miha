from PySide6.QtCore import Qt, QRectF
from PySide6.QtGui import QPainter, QColor, QPen, QFont
from PySide6.QtWidgets import QWidget

class IntersectionView(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent); self.setMinimumSize(500,400)
    def paintEvent(self,event):
        p=QPainter(self); p.setRenderHint(QPainter.RenderHint.Antialiasing)
        p.fillRect(self.rect(),QColor("#e8eee8"))
        w,h=self.width(),self.height(); cx,cy=w/2,h/2; rw=min(w,h)*.30
        p.setPen(Qt.PenStyle.NoPen); p.setBrush(QColor("#50565c"))
        p.drawRect(QRectF(cx-rw/2,0,rw,h)); p.drawRect(QRectF(0,cy-rw/2,w,rw))
        p.setPen(QPen(QColor("#f8f0d7"),2,Qt.PenStyle.DashLine))
        p.drawLine(int(cx),0,int(cx),int(cy-rw/2)); p.drawLine(int(cx),int(cy+rw/2),int(cx),h)
        p.drawLine(0,int(cy),int(cx-rw/2),int(cy)); p.drawLine(int(cx+rw/2),int(cy),w,int(cy))
        p.setPen(Qt.PenStyle.NoPen)
        for x,y,col in [(cx-28,cy-rw/2-25,"#299b56"),(cx+rw/2+25,cy+28,"#299b56"),
                        (cx+28,cy+rw/2+25,"#c93d42"),(cx-rw/2-25,cy-28,"#c93d42")]:
            p.setBrush(QColor(col)); p.drawEllipse(int(x-8),int(y-8),16,16)
        p.setPen(QColor("#202020")); p.setFont(QFont("Segoe UI",10))
        p.drawText(12,24,"СЕВЕР"); p.drawText(w-80,24,"ВОСТОК")
        p.drawText(12,h-14,"ЗАПАД"); p.drawText(w-70,h-14,"ЮГ")
        p.drawText(12,h-40,"Условная схема — не импортирована из 2ГИС")
