from PySide6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QTabWidget, QLabel,
    QPushButton, QFormLayout, QDoubleSpinBox, QSpinBox, QTableWidget,
    QTableWidgetItem, QHeaderView, QMessageBox, QTextEdit, QGroupBox,
    QLineEdit, QComboBox, QFileDialog
)
from app.editor.intersection_view import IntersectionView
from app.signals.plan import Phase, SignalPlan
from app.simulation.engine import SimulationConfig, run_simulation
from app.integrations.dgis import DGisClient, DGisError
from app.settings import load_settings, save_settings
from app.integrations.road_network import fetch_osm_roads, load_geojson, save_geojson, RoadNetworkError

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("TrafficSignalStudio — моделирование светофорных объектов")
        self.resize(1220, 820)
        self.settings = load_settings()
        self.road_network = None
        self.plan = SignalPlan.default()
        tabs = QTabWidget()
        tabs.addTab(self._build_map_tab(), "2ГИС / импорт")
        tabs.addTab(self._build_scheme_tab(), "Схема")
        tabs.addTab(self._build_signals_tab(), "Светофорная программа")
        tabs.addTab(self._build_demand_tab(), "Транспортный поток")
        tabs.addTab(self._build_results_tab(), "Результаты")
        self.tabs = tabs
        self.setCentralWidget(tabs)
        self.statusBar().showMessage("Прототип: проверяйте доступность API и валидируйте расчёты перед инженерным применением.")

    def _build_map_tab(self):
        w = QWidget(); l = QVBoxLayout(w)
        intro = QLabel("2ГИС Places API используется для поиска объектов, но не считается источником дорожной топологии. Для геометрии доступен импорт дорожных линий OpenStreetMap (Overpass) и открытие GeoJSON. Данные проверяйте по лицензии и точности перед инженерным использованием.")
        intro.setWordWrap(True); l.addWidget(intro)
        formbox = QGroupBox("Настройки API 2ГИС"); f = QFormLayout(formbox)
        self.api_key = QLineEdit(self.settings.get("dgis_api_key", ""))
        self.api_key.setEchoMode(QLineEdit.EchoMode.Password)
        self.query = QLineEdit("перекрёсток")
        self.lat = QDoubleSpinBox(); self.lat.setRange(-90,90); self.lat.setDecimals(6); self.lat.setValue(55.751244)
        self.lon = QDoubleSpinBox(); self.lon.setRange(-180,180); self.lon.setDecimals(6); self.lon.setValue(37.618423)
        self.radius = QSpinBox(); self.radius.setRange(100,50000); self.radius.setValue(1500); self.radius.setSuffix(" м")
        f.addRow("API-ключ", self.api_key); f.addRow("Поисковый запрос", self.query)
        f.addRow("Широта", self.lat); f.addRow("Долгота", self.lon); f.addRow("Радиус", self.radius)
        l.addWidget(formbox)
        buttons = QHBoxLayout()
        save = QPushButton("Сохранить ключ локально"); save.clicked.connect(self._save_key); buttons.addWidget(save)
        search = QPushButton("Поиск объектов в 2ГИС"); search.clicked.connect(self._search_dgis); buttons.addWidget(search)
        l.addLayout(buttons)
        road_box = QGroupBox("Дорожная геометрия (не является импортом из 2ГИС)")
        road_layout = QVBoxLayout(road_box)
        road_note = QLabel("Импортирует линии дорог из OpenStreetMap через публичный Overpass API в пределах небольшого прямоугольника вокруг заданной точки. Это геометрия дорог, не готовая модель полос/фаз.")
        road_note.setWordWrap(True); road_layout.addWidget(road_note)
        road_buttons = QHBoxLayout()
        osm = QPushButton("Импортировать дороги OSM вокруг точки"); osm.clicked.connect(self._import_osm_roads); road_buttons.addWidget(osm)
        geo = QPushButton("Открыть GeoJSON"); geo.clicked.connect(self._open_geojson); road_buttons.addWidget(geo)
        save_geo = QPushButton("Сохранить импорт GeoJSON"); save_geo.clicked.connect(self._save_geojson); road_buttons.addWidget(save_geo)
        road_layout.addLayout(road_buttons)
        l.addWidget(road_box)
        self.dgis_results = QTextEdit(); self.dgis_results.setReadOnly(True)
        self.dgis_results.setPlaceholderText("Здесь появятся результаты поиска 2ГИС или состояние импорта дорожных данных.")
        l.addWidget(self.dgis_results, 1)
        return w

    def _import_osm_roads(self):
        from math import cos, radians
        lat, lon = self.lat.value(), self.lon.value()
        radius_km = min(self.radius.value() / 1000.0, 2.0)
        dlat = radius_km / 111.0
        dlon = radius_km / max(20.0, 111.0 * abs(cos(radians(lat))))
        self.dgis_results.setPlainText("Запрашиваются дорожные линии из OpenStreetMap/Overpass…")
        try:
            self.road_network = fetch_osm_roads(lat-dlat, lon-dlon, lat+dlat, lon+dlon)
            features = self.road_network.get("features", [])
            highways = {}
            for feature in features:
                kind = feature.get("properties", {}).get("highway", "unknown")
                highways[kind] = highways.get(kind, 0) + 1
            summary = "\n".join(f"  {k}: {v}" for k, v in sorted(highways.items()))
            report = (f"Импортировано линейных объектов: {len(features)}\n"
                      f"Источник: OpenStreetMap через Overpass API\n\nТипы highway:\n{summary}\n\n"
                      "Ограничение: это линии дорог, не полосы движения, не направления разрешённых поворотов "
                      "и не контроллер светофора. Для моделирования потребуется очистка/конвертация и проверка геометрии.")
            self.dgis_results.setPlainText(report)
        except RoadNetworkError as exc:
            QMessageBox.warning(self, "Ошибка импорта дорожной сети", str(exc))
            self.dgis_results.setPlainText(str(exc))

    def _open_geojson(self):
        path, _ = QFileDialog.getOpenFileName(self, "Открыть дорожную сеть GeoJSON", "", "GeoJSON (*.geojson *.json)")
        if not path: return
        try:
            self.road_network = load_geojson(path)
            count = len(self.road_network["features"])
            linear = sum(1 for f in self.road_network["features"] if f.get("geometry", {}).get("type") in ("LineString", "MultiLineString"))
            self.dgis_results.setPlainText(f"Открыт GeoJSON: {path}\nОбъектов: {count}\nЛинейных дорожных объектов: {linear}")
        except RoadNetworkError as exc:
            QMessageBox.warning(self, "Ошибка GeoJSON", str(exc))

    def _save_geojson(self):
        if not self.road_network:
            QMessageBox.information(self, "Нет данных", "Сначала импортируйте дороги или откройте GeoJSON."); return
        path, _ = QFileDialog.getSaveFileName(self, "Сохранить дорожную сеть", "road_network.geojson", "GeoJSON (*.geojson)")
        if not path: return
        try:
            if not path.lower().endswith((".geojson", ".json")): path += ".geojson"
            save_geojson(self.road_network, path)
            QMessageBox.information(self, "Экспорт", f"GeoJSON сохранён:\n{path}")
        except OSError as exc:
            QMessageBox.critical(self, "Ошибка сохранения", str(exc))

    def _save_key(self):
        self.settings["dgis_api_key"] = self.api_key.text().strip()
        save_settings(self.settings)
        QMessageBox.information(self, "Настройки", "Ключ сохранён в локальном settings.json. Не публикуйте этот файл и не включайте его в общий архив.")

    def _search_dgis(self):
        key = self.api_key.text().strip()
        if not key:
            QMessageBox.warning(self, "Нужен API-ключ", "Получите API-ключ в кабинете разработчика 2ГИС и вставьте его сюда.")
            return
        self.dgis_results.setPlainText("Выполняется запрос к 2ГИС Places API…")
        from PySide6.QtCore import QThread, Signal
        class Worker(QThread):
            done = Signal(object, object)
            def run(inner_self):
                try:
                    client = DGisClient(key)
                    data = client.search(self.query.text().strip(), self.lat.value(), self.lon.value(), self.radius.value())
                    inner_self.done.emit(data, None)
                except Exception as e:
                    inner_self.done.emit(None, str(e))
        self.worker = Worker()
        self.worker.done.connect(self._show_dgis_results)
        self.worker.start()

    def _show_dgis_results(self, data, error):
        if error:
            self.dgis_results.setPlainText(
                "Не удалось получить ответ от 2ГИС.\n"
                f"Причина: {error}\n\n"
                "Проверьте API-ключ, доступ к Places API, сетевое подключение и актуальные условия API."
            )
            return
        items = data.get("result", {}).get("items", [])
        lines = [f"Найдено объектов: {len(items)}", ""]
        for i, item in enumerate(items, 1):
            name = item.get("name", "Без названия")
            address = item.get("address_name", "Адрес не указан")
            point = item.get("point", {})
            coords = ""
            if point:
                coords = f" | координаты: {point.get('lat')}, {point.get('lon')}"
            lines.append(f"{i}. {name}\n   {address}{coords}")
        if not items:
            lines.append("Пустой результат. Попробуйте другой запрос или проверьте параметры поиска.")
        lines += ["", "Примечание: найденные места не являются автоматически импортированной дорожной сетью."]
        self.dgis_results.setPlainText("\n".join(lines))

    def _build_scheme_tab(self):
        w = QWidget(); layout = QVBoxLayout(w)
        intro = QLabel("Условная четырёхсторонняя схема. Импортированная геометрия пока сохраняется в GeoJSON и не отображается в редакторе; полосы и повороты не выводятся автоматически.")
        intro.setWordWrap(True); layout.addWidget(intro)
        self.scheme = IntersectionView(); layout.addWidget(self.scheme, 1)
        return w

    def _build_signals_tab(self):
        w = QWidget(); layout = QVBoxLayout(w)
        note = QLabel("Демонстрационный двухфазный план. До реального применения требуется проверка конфликтов направлений и нормативных интервалов.")
        note.setWordWrap(True); layout.addWidget(note)
        self.phase_table = QTableWidget(2, 4)
        self.phase_table.setHorizontalHeaderLabels(["Фаза", "Зелёный, с", "Жёлтый, с", "Межфазный, с"])
        self.phase_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        for r, row in enumerate([("Север—Юг", 35, 3, 2), ("Восток—Запад", 30, 3, 2)]):
            for c, val in enumerate(row): self.phase_table.setItem(r, c, QTableWidgetItem(str(val)))
        layout.addWidget(self.phase_table)
        btn = QPushButton("Проверить и применить план"); btn.clicked.connect(self._apply_phases); layout.addWidget(btn)
        self.phase_summary = QLabel(); layout.addWidget(self.phase_summary); self._apply_phases()
        return w

    def _build_demand_tab(self):
        w = QWidget(); outer = QVBoxLayout(w); box = QGroupBox("Параметры сценария"); f = QFormLayout(box)
        self.ns = QSpinBox(); self.ns.setRange(0,5000); self.ns.setValue(900); self.ns.setSuffix(" авт./ч")
        self.ew = QSpinBox(); self.ew.setRange(0,5000); self.ew.setValue(700); self.ew.setSuffix(" авт./ч")
        self.heavy = QDoubleSpinBox(); self.heavy.setRange(0,100); self.heavy.setValue(10); self.heavy.setSuffix(" %")
        self.duration = QSpinBox(); self.duration.setRange(60,7200); self.duration.setValue(1800); self.duration.setSuffix(" с")
        self.saturation = QSpinBox(); self.saturation.setRange(900,2400); self.saturation.setValue(1800); self.saturation.setSuffix(" авт./ч")
        self.seed = QSpinBox(); self.seed.setRange(1,999999); self.seed.setValue(42)
        for label, widget in [("Поток Север—Юг",self.ns),("Поток Восток—Запад",self.ew),("Доля тяжёлых ТС",self.heavy),("Длительность",self.duration),("Насыщенная интенсивность",self.saturation),("Seed сценария",self.seed)]: f.addRow(label,widget)
        outer.addWidget(box)
        note = QLabel("Агрегированная демонстрационная модель: потоки по двум осям. Повороты, пешеходы, погода и влияние тяжёлых ТС на динамику не моделируются.")
        note.setWordWrap(True); outer.addWidget(note)
        run = QPushButton("Запустить моделирование"); run.clicked.connect(self._run); outer.addWidget(run); outer.addStretch()
        return w

    def _build_results_tab(self):
        w = QWidget(); l = QVBoxLayout(w); self.results_text = QTextEdit(); self.results_text.setReadOnly(True)
        self.results_text.setPlaceholderText("Запустите моделирование на вкладке «Транспортный поток».")
        l.addWidget(self.results_text); return w

    def _apply_phases(self):
        try:
            phases = []
            for r, name in enumerate(["Север—Юг", "Восток—Запад"]):
                green = int(self.phase_table.item(r,1).text())
                yellow = int(self.phase_table.item(r,2).text())
                intergreen = int(self.phase_table.item(r,3).text())
                if green < 5 or yellow < 1 or intergreen < 0:
                    raise ValueError("Зелёный ≥ 5 с, жёлтый ≥ 1 с, межфазный интервал ≥ 0.")
                phases.append(Phase(name,green,yellow,intergreen))
            self.plan = SignalPlan(phases)
            self.phase_summary.setText(f"Расчётная длина цикла: {self.plan.cycle_seconds} с")
            self.scheme.update()
            return True
        except Exception as e:
            QMessageBox.warning(self, "Некорректный план", str(e)); return False

    def _run(self):
        if not self._apply_phases(): return
        cfg = SimulationConfig(self.ns.value(), self.ew.value(), self.heavy.value(),
                               self.duration.value(), self.saturation.value(), self.seed.value())
        result = run_simulation(cfg, self.plan)
        self.results_text.setPlainText(result.to_report())
        self.tabs.setCurrentIndex(4)
